﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BudgetPlanner
{
    class Expenses
    {
         
        private List<Expense> allexpenses = new List<Expense>();

        public void add(Expense input)
        {
            allexpenses.Add(input);

        }
    }
}
 
