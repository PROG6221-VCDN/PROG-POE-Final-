﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BudgetPlanner
{

    class Rent : Expense
    {
        private double Rent_amount;

        public Rent(double rent_amount)
        {
            Rent_amount = rent_amount;
        }

        public double Rent_amount1 { get => Rent_amount; set => Rent_amount = value; }

        public double total()
        {
            return Rent_amount;


        }

    }

}   


