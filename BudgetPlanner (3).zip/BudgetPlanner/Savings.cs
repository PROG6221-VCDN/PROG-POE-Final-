﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BudgetPlanner
{
    class Savings
    

    {
        
        private double Amount_saving;
        private double No_of_years;
        private double Interest_rate;

        public Savings(double amount_saving, double no_of_years, double interest_rate)
        {
            Amount_saving = amount_saving;
            No_of_years = no_of_years;
            Interest_rate = interest_rate;
        }

        public double Amount_saving1 { get => Amount_saving; set => Amount_saving = value; }
        public double No_of_years1 { get => No_of_years; set => No_of_years = value; }
        public double Interest_rate1 { get => Interest_rate; set => Interest_rate = value; }

        public double Amount()
        { 
            double monthlySaving = 0;
    double r = Interest_rate / 100;
   double numYears = (double)No_of_years / 12;
    int frequency = 12;
    double brackets = (Math.Pow((1 + r), numYears + 1) - (1 + r));
   monthlySaving = Amount_saving / (frequency* brackets/r);
    return Math.Round(monthlySaving,2);

   

        }
        

    }
    
}

 

