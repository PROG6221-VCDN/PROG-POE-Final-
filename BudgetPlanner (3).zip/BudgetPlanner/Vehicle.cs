﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BudgetPlanner
{
    class Vehicle
    {
         
        private string Make_and_model;
        private double Purchase_price;
        private double Total_deposits;
        private double Interest_rate;
        private double Estimated_insurance_premium;

        public Vehicle(string make_and_model, double purchase_price, double total_deposits, double interest_rate, double estimated_insurance_premium)
        {
            Make_and_model = make_and_model;
            Purchase_price = purchase_price;
            Total_deposits = total_deposits;
            Interest_rate = interest_rate;
            Estimated_insurance_premium = estimated_insurance_premium;
        }

        public string Make_and_model1 { get => Make_and_model; set => Make_and_model = value; }
        public double Purchase_price1 { get => Purchase_price; set => Purchase_price = value; }
        public double Total_deposits1 { get => Total_deposits; set => Total_deposits = value; }
        public double Interest_rate1 { get => Interest_rate; set => Interest_rate = value; }
        public double Estimated_insurance_premium1 { get => Estimated_insurance_premium; set => Estimated_insurance_premium = value; }

        public double total()

        {
            return (Purchase_price - Total_deposits) * Math.Pow(1 + Interest_rate / 100, 60 / 12);




        }
    }
}
