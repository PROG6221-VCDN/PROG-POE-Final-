﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BudgetPlanner
{
    class Home_Loan
    {
        class Home_loan : Expense
        {
            private double Purchase_price_of_property;
            private double Total_deposit;
            private double Interest_rate;
            private double Number_of_months_to_repay;

            public Home_loan(double purchase_price_of_property, double total_deposit, double interest_rate, double number_of_months_to_repay)
            {
                Purchase_price_of_property = purchase_price_of_property;
                Total_deposit = total_deposit;
                Interest_rate = interest_rate;
                Number_of_months_to_repay = number_of_months_to_repay;
            }

            public double Purchase_price_of_property1 { get => Purchase_price_of_property; set => Purchase_price_of_property = value; }
            public double Total_deposit1 { get => Total_deposit; set => Total_deposit = value; }
            public double Interest_rate1 { get => Interest_rate; set => Interest_rate = value; }
            public double Number_of_months_to_repay1 { get => Number_of_months_to_repay; set => Number_of_months_to_repay = value; }

            public double total()

            {
                return (Purchase_price_of_property - Total_deposit) * Math.Pow(1 + Interest_rate / 100, Number_of_months_to_repay / 12);




            }

        }
}   }  

