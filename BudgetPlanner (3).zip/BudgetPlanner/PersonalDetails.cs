﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BudgetPlanner
{
    class PersonalDetails
    {
         
        private double full_name;
        private double monthly_income;
        private double taxes_deducted;
        private Expenses userexpenses;

        public PersonalDetails(double full_name, double monthly_income, double taxes_deducted, Expenses userexpenses)
        {
            this.full_name = full_name;
            this.monthly_income = monthly_income;
            this.taxes_deducted = taxes_deducted;
            this.userexpenses = userexpenses;
        }
    }
}

