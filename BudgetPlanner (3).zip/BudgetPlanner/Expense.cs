﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BudgetPlanner

{
   public abstract class Expense
    {



    }
}
