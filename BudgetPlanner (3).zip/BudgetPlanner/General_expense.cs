﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BudgetPlanner

{
    
        class General_expense : Expense
        {
            private double Groceries;
            private double Water_and_lights;
            private double Travel_costs;
            private double Cellphone_and_telephones;
            private double Other_expenses;

            public General_expense(double groceries, double water_and_lights, double travel_costs, double cellphone_and_telephones, double other_expenses)
            {
                Groceries = groceries;
                Water_and_lights = water_and_lights;
                Travel_costs = travel_costs;
                Cellphone_and_telephones = cellphone_and_telephones;
                Other_expenses = other_expenses;


            }

            public double Groceries1 { get => Groceries; set => Groceries = value; }
            public double Water_and_lights1 { get => Water_and_lights; set => Water_and_lights = value; }
            public double Travel_costs1 { get => Travel_costs; set => Travel_costs = value; }
            public double Cellphone_and_telephones1 { get => Cellphone_and_telephones; set => Cellphone_and_telephones = value; }
            public double Other_expenses1 { get => Other_expenses; set => Other_expenses = value; }

            public double total()
            {
                return Groceries + Water_and_lights + Travel_costs + Cellphone_and_telephones + Other_expenses;


            }
        }
    
}