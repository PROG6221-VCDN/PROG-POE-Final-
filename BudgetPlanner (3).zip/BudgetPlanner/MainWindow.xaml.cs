﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace BudgetPlanner
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            {

                rentalamount.Visibility = Visibility.Hidden;
                rentalamount_label.Visibility = Visibility.Hidden;

                Purchasepriceofproperty_Label.Visibility = Visibility.Hidden;
                Totaldeposit_Label.Visibility = Visibility.Hidden;
                Interestrate_Label.Visibility = Visibility.Hidden;
                Numberofmonthstorepay_Label.Visibility = Visibility.Hidden;
                Purchasepriceofproperty.Visibility = Visibility.Hidden;
                Totaldeposit.Visibility = Visibility.Hidden;
                Interestrate.Visibility = Visibility.Hidden;
                Numberofmonthstorepay.Visibility = Visibility.Hidden;

                lblVehicleSpec.Visibility = Visibility.Hidden;
                lblPurchasePrice.Visibility = Visibility.Hidden;
                lblTotalDeposit.Visibility = Visibility.Hidden;
                lblInterestRateVehichle.Visibility = Visibility.Hidden;
                lblInsurancePremium.Visibility = Visibility.Hidden;


                txbEstimatedInsurancePremium.Visibility = Visibility.Hidden;
                txbVehicleInterestRate.Visibility = Visibility.Hidden;
                txbVehicleTotalDeposits.Visibility = Visibility.Hidden;
                txbVehiclePurchasePrice.Visibility = Visibility.Hidden;
                txbVehicleSpecs.Visibility = Visibility.Hidden;

            }
        }

        private void Submit_Click(object sender, RoutedEventArgs e)
        {
            if (rbPurchaseVehicle.IsChecked == true)
            {
                string name = fullnametxb.Text;
                double income = double.Parse(Grossmonthlyincome.Text);
                double tax = double.Parse(Estimatedmonthlydeducted.Text);
                Expenses userexpenses = new Expenses();
                string Make_and_model = txbVehicleSpecs.Text;
                double Purchase_price = double.Parse(txbVehiclePurchasePrice.Text);
                double Total_deposits = double.Parse(txbVehicleTotalDeposits.Text);
                double Interest_rate = double.Parse(txbVehicleInterestRate.Text);
                double Estimated_insurance_premium = double.Parse(txbEstimatedInsurancePremium.Text);
                Vehicle spec = new Vehicle(Make_and_model, Purchase_price, Total_deposits, Interest_rate, Estimated_insurance_premium);
                MessageBox.Show("Vehicle Loan: " + spec.total().ToString());


            }



            double Groceries = double.Parse(txbGroceries1.Text);
            double Water_and_lights = double.Parse(txbWaterAndLights.Text);
            double Travel_costs = double.Parse(txbTravelCosts.Text);
            double Cellphone_and_telephones = double.Parse(Cellphoneandtelephone.Text);
            double Other_expenses = double.Parse(Otherexpenses.Text);
            //get inputs for all variables to make a generic expense object
            General_expense newGeneric = new General_expense(Groceries, Water_and_lights, Travel_costs, Cellphone_and_telephones, Other_expenses);

            var _grossmonthlyincome = Convert.ToDecimal(Grossmonthlyincome.Text);
            //deduction variables start

            var _totaldeductedamount =

                (Convert.ToDecimal(Estimatedmonthlydeducted.Text == string.Empty ? "0" : Estimatedmonthlydeducted.Text) +
                Convert.ToDecimal(txbGroceries1.Text == string.Empty ? "0" : txbGroceries1.Text) +
                Convert.ToDecimal(txbWaterAndLights.Text == string.Empty ? "0" : txbWaterAndLights.Text) +
                Convert.ToDecimal(txbTravelCosts.Text == string.Empty ? "0" : txbTravelCosts.Text) +
               Convert.ToDecimal(Cellphoneandtelephone.Text == string.Empty ? "0" : Cellphoneandtelephone.Text) +
               Convert.ToDecimal(Otherexpenses.Text == string.Empty ? "0" : Otherexpenses.Text));
            if (rbRentingAccommodation.IsChecked == true)
            {
                _totaldeductedamount = _totaldeductedamount +
                    (Convert.ToInt32(rentalamount.Text == string.Empty ? "0" : rentalamount.Text));
                if (_grossmonthlyincome > _totaldeductedamount)
                {
                    MessageBox.Show("You are eligible to rent the property. : " + " Gross Monthly income : " + _grossmonthlyincome + ", monthly expenditures " + _totaldeductedamount + ", After expenditures : " + (_grossmonthlyincome - _totaldeductedamount), "Success");
                }
                else
                {
                    MessageBox.Show("You might not eligible to rent the property. : " + " Gross Monthly income:" + _grossmonthlyincome + ", monthly expenditures " + _totaldeductedamount + ", After expenditures : " + (_grossmonthlyincome - _totaldeductedamount), "Error");
                }
            }
            else
            {

                //----------------------------------------Code Attribution----------------------------------------//
                //Adapted from : https://docs.microsoft.com/en-us/dotnet/api/system.convert.todecimal?view=net-5.0 
                //Author/s: not specified 
                //Date Accesed: 18 April 2021


                var _Purchasepriceofproperty = (Convert.ToDecimal(Purchasepriceofproperty.Text) - Convert.ToDecimal(Totaldeposit.Text));
                var _Interestrate = Convert.ToDecimal(Interestrate.Text) / 100;
                var _Numberofmonthstorepay = Convert.ToDecimal(Numberofmonthstorepay.Text) / 12;
                var calculatebuyingproperty = _Purchasepriceofproperty * (1 + _Interestrate * _Numberofmonthstorepay);
                var _monthlypayment = (calculatebuyingproperty / Convert.ToDecimal(Numberofmonthstorepay.Text));
                var _grossmonthlydividentby3parts = (_grossmonthlyincome / 3);
                if (_grossmonthlydividentby3parts > _monthlypayment)
                {
                    MessageBox.Show("You are eligible for this home loan. : " + " Gross Monthly income : " + _grossmonthlyincome + ", monthly expenditures " + _totaldeductedamount + ", After expenditures : " + (_grossmonthlyincome - _totaldeductedamount), "Success");
                }
                else
                {
                    MessageBox.Show("You might not eligible for this home loan. : " + " Gross Monthly income:" + _grossmonthlyincome + ", monthly expenditures " + _totaldeductedamount + ", After expenditures : " + (_grossmonthlyincome - _totaldeductedamount), "Error");
                }
            }

            //deduction variables end

        }

        private void rbRentingAccommodation_Checked(object sender, RoutedEventArgs e)
        {
            rentalamount.Visibility = Visibility.Visible;
            rentalamount_label.Visibility = Visibility.Visible;

            Purchasepriceofproperty_Label.Visibility = Visibility.Hidden;
            Totaldeposit_Label.Visibility = Visibility.Hidden;
            Interestrate_Label.Visibility = Visibility.Hidden;
            Numberofmonthstorepay_Label.Visibility = Visibility.Hidden;
            Purchasepriceofproperty.Visibility = Visibility.Hidden;
            Totaldeposit.Visibility = Visibility.Hidden;
            Interestrate.Visibility = Visibility.Hidden;
            Numberofmonthstorepay.Visibility = Visibility.Hidden;
        }

        private void rbBuyingAProperty_Checked(object sender, RoutedEventArgs e)
        {
            rentalamount.Visibility = Visibility.Hidden;
            rentalamount_label.Visibility = Visibility.Hidden;

            Purchasepriceofproperty_Label.Visibility = Visibility.Visible;
            Totaldeposit_Label.Visibility = Visibility.Visible;
            Interestrate_Label.Visibility = Visibility.Visible;
            Numberofmonthstorepay_Label.Visibility = Visibility.Visible;
            Purchasepriceofproperty.Visibility = Visibility.Visible;
            Totaldeposit.Visibility = Visibility.Visible;
            Interestrate.Visibility = Visibility.Visible;
            Numberofmonthstorepay.Visibility = Visibility.Visible;
        }
        public void cleartext()
        {
            rentalamount.Text = string.Empty;
            Purchasepriceofproperty.Text = string.Empty;
            Totaldeposit.Text = string.Empty;
            Interestrate.Text = string.Empty;
            Numberofmonthstorepay.Text = string.Empty;
            Grossmonthlyincome.Text = string.Empty;
            fullnametxb.Text = string.Empty;
            txbVehicleInterestRate.Text = string.Empty;
            Numberofmonthstorepay.Text = string.Empty;
        }

        private void rbPurchaseVehicle_Checked(object sender, RoutedEventArgs e)
        {
            lblVehicleSpec.Visibility = Visibility.Visible;
            lblPurchasePrice.Visibility = Visibility.Visible;
            lblTotalDeposit.Visibility = Visibility.Visible;
            lblInterestRateVehichle.Visibility = Visibility.Visible;
            lblInsurancePremium.Visibility = Visibility.Visible;


            txbEstimatedInsurancePremium.Visibility = Visibility.Visible;
            txbVehicleInterestRate.Visibility = Visibility.Visible;
            txbVehicleTotalDeposits.Visibility = Visibility.Visible;
            txbVehiclePurchasePrice.Visibility = Visibility.Visible;
            txbVehicleSpecs.Visibility = Visibility.Visible;
        }

        private void Grossmonthlyincome_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void Numberofmonthstorepay_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void TextBox_TextChanged_1(object sender, TextChangedEventArgs e)
        {

        }

        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void rbSaving_Checked(object sender, RoutedEventArgs e)
        {
            lblAmntSaving.Visibility = Visibility.Visible;
            lblYears.Visibility = Visibility.Visible;
            lblSavingsInterestRate.Visibility = Visibility.Visible;

            txbAmntSaving.Visibility = Visibility.Visible;
            txbAmntOfYears.Visibility = Visibility.Visible;
            txbSavingsInterestRate.Visibility = Visibility.Visible;
        }
    }
}
    


